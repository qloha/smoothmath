def add(x, y):
    result = x + y
    print(result)