def subtract(x, y):
    result = x - y
    print(result)