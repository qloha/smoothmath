# EasyMath

The easiest math package!

## How to install:

To install this package, run ```pip install easymath```

## Tutorial

Some things that this package includes is the add & subtract function. Here's an example of the add: