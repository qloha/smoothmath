from smoothmath.simplemath import add, subtract, multiply, divide
from smoothmath.evaluate import evaluate, eval